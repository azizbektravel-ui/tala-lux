#!/usr/bin/env bash
set -euo pipefail

mkdir -p public/products

echo "Downloading verified TALA LUX product reference images..."

# 1. Dishwashing Gel (official talalux.uz transparent cutout + Uzum Market 700g backup)
curl -fL "https://talalux.uz/thumb/2/1g0RePlZ_md9FLzqinBFYw/1200r/d/erasebg-transformed.png" -o public/products/dishwash.png   || curl -fL "https://images.uzum.uz/d51a2e0jsv1neacpm3cg/t_product_540_high.jpg" -o public/products/dishwash.jpg

# 2. Laundry Detergent (Uzum Market TALA LUX 3L 'Tog yangiligi' / 2.4L)
curl -fL "https://images.uzum.uz/d8a1la49g1ktqmlpeg60/t_product_540_high.jpg" -o public/products/laundry-raw.jpg

# 3. Stain Remover / Oxygen Cleaner (Uzum Market TALA LUX Oxygen Cleaner)
curl -fL "https://images.uzum.uz/d6ekq27qkmak8dt8f9j0/t_product_540_high.jpg" -o public/products/stain-remover-raw.jpg

# 4. Liquid Cream Soap (Uzum Market TALA LUX 500ml)
curl -fL "https://images.uzum.uz/d6ekpag9oh610dh8s7n0/t_product_540_high.jpg" -o public/products/liquid-soap-raw.jpg

echo "Done! Remove backgrounds on *-raw.jpg files (e.g. with rembg) and save as:"
echo "  public/products/dishwash.png"
echo "  public/products/laundry.png"
echo "  public/products/stain-remover.png"
echo "  public/products/glass-cleaner.png"
