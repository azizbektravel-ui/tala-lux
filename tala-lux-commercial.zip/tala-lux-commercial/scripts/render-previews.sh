#!/usr/bin/env bash
set -euo pipefail

mkdir -p out/previews

for frame in 120 360 660 960 1260 1560 1740; do
  echo "Rendering preview frame ${frame}..."
  npx remotion still src/index.ts TalaLux "out/previews/frame-${frame}.png" --frame="${frame}"
done

echo "All 7 QC preview frames rendered in out/previews/."
