# TALA LUX — CLEAN WORLD (30s 9:16 60fps CGI Commercial)

Production-ready Remotion + React Three Fiber + TypeScript project for the 30-second vertical (1080×1920, 60fps, 1800 frames) TALA LUX commercial.

## Included Assets
- `public/logo.png` — Transparent PNG extracted from the official TALA LUX brand logo.
- `public/products/lineup-reference.jpg` — Official TALA LUX product lineup banner.
- `scripts/download-assets.sh` — Downloads verified product images from `talalux.uz` and Uzum Market.
- `voiceover/elevenlabs-clips.json` — Per-scene Uzbek TTS script and exact frame cues.

## Quick Start
```bash
npm install
npm run typecheck
npm run download:assets
```

1. Place transparent cutout PNGs in `public/products/`:
   - `dishwash.png`
   - `laundry.png`
   - `stain-remover.png`
   - `glass-cleaner.png`
2. Place ElevenLabs voiceover clips (`voice-01.mp3`–`voice-06.mp3`), licensed music (`music.mp3`), and SFX (`splash.wav`, `whoosh.wav`, `impact.wav`) in `public/audio/`, then set `enableAudio={true}` in `src/Commercial.tsx`.
3. Render previews and final H.264/AAC MP4:
```bash
npm run render:previews
npm run render:test
npm run render
ffprobe -v error -show_format -show_streams out/talalux-final.mp4
```
