import React from 'react';
import {
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from 'remotion';

interface FloatingProductProps {
  image: string;
  width?: number;
  delay?: number;
  floatAmplitude?: number;
  tiltDegrees?: number;
  rimGlowColor?: string;
  showContactShadow?: boolean;
}

/**
 * Premium 2.5D product compositor for transparent high-res PNG packaging.
 * Preserves exact original packaging proportions and readability without fake 360° rotation.
 */
export const FloatingProduct: React.FC<FloatingProductProps> = ({
  image,
  width = 640,
  delay = 0,
  floatAmplitude = 16,
  tiltDegrees = 1.8,
  rimGlowColor = 'rgba(130, 225, 255, 0.35)',
  showContactShadow = true,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const localFrame = Math.max(0, frame - delay);

  const entrance = spring({
    frame: localFrame,
    fps,
    config: {
      damping: 20,
      stiffness: 85,
      mass: 1.15,
    },
  });

  const t = localFrame / fps;
  const floatY = Math.sin(t * 2.0) * floatAmplitude;
  const subtleTilt = Math.sin(t * 1.15) * tiltDegrees;
  const pushScale = interpolate(localFrame, [0, 300], [1.0, 1.045], {
    extrapolateRight: 'clamp',
  });
  const scale = interpolate(entrance, [0, 1], [0.84, 1]) * pushScale;
  const opacity = interpolate(localFrame, [0, 18], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const shadowScale = interpolate(
    floatY,
    [-floatAmplitude, floatAmplitude],
    [0.86, 1.06]
  );

  return (
    <div
      style={{
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        perspective: 1200,
      }}
    >
      <Img
        src={staticFile(image)}
        style={{
          width,
          maxHeight: 1120,
          opacity,
          objectFit: 'contain',
          transform: `translateY(${floatY}px) rotate(${subtleTilt}deg) scale(${scale})`,
          filter: `drop-shadow(0 36px 34px rgba(0, 8, 20, 0.48)) drop-shadow(0 0 28px ${rimGlowColor})`,
        }}
      />
      {showContactShadow && (
        <div
          style={{
            width: width * 0.62,
            height: 36,
            marginTop: 14,
            borderRadius: '50%',
            background:
              'radial-gradient(ellipse at center, rgba(0, 10, 24, 0.55) 0%, rgba(0, 10, 24, 0) 72%)',
            transform: `scale(${shadowScale * entrance})`,
            opacity: opacity * 0.85,
          }}
        />
      )}
    </div>
  );
};
