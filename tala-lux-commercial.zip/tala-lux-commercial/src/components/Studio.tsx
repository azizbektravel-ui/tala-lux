import React from 'react';
import {ThreeCanvas} from '@remotion/three';
import {Environment, Lightformer} from '@react-three/drei';
import {EffectComposer, Bloom, Vignette} from '@react-three/postprocessing';
import {useCurrentFrame, interpolate} from 'remotion';
import {Bubbles} from './Bubbles';

export interface StudioTheme {
  bgColor: string;
  floorColor: string;
  podiumColor: string;
  rimLightColor: string;
  bubbleColor: string;
  multiTierPodium?: boolean;
  cameraDollyZ?: [number, number];
}

interface StudioProps {
  theme?: Partial<StudioTheme>;
  durationInFrames?: number;
}

const DEFAULT_THEME: StudioTheme = {
  bgColor: '#0c233a',
  floorColor: '#12334d',
  podiumColor: '#d8e9fa',
  rimLightColor: '#51bfff',
  bubbleColor: '#b9efff',
  multiTierPodium: false,
  cameraDollyZ: [9.4, 8.2],
};

export const Studio: React.FC<StudioProps> = ({
  theme = {},
  durationInFrames = 300,
}) => {
  const frame = useCurrentFrame();
  const t = {...DEFAULT_THEME, ...theme};

  const camZ = interpolate(
    frame,
    [0, durationInFrames],
    t.cameraDollyZ ?? [9.4, 8.2],
    {extrapolateRight: 'clamp'}
  );

  return (
    <ThreeCanvas
      width={1080}
      height={1920}
      shadows
      dpr={[1, 2]}
      camera={{
        position: [0, 2.8, camZ],
        fov: 38,
      }}
    >
      <color attach="background" args={[t.bgColor]} />
      <fog attach="fog" args={[t.bgColor, 10, 28]} />

      <ambientLight intensity={0.65} />
      <spotLight
        position={[4.5, 8.5, 5.5]}
        intensity={90}
        angle={0.42}
        penumbra={0.85}
        castShadow
      />
      <pointLight
        position={[-4.5, 3.2, -2.5]}
        intensity={42}
        color={t.rimLightColor}
      />
      <pointLight position={[3.5, 1.5, -4]} intensity={24} color="#ffffff" />

      {/* Procedural softbox reflections (no external HDRI fetch required) */}
      <Environment resolution={256}>
        <Lightformer
          form="rect"
          intensity={2.4}
          position={[0, 6, 2]}
          scale={[10, 3, 1]}
          rotation={[Math.PI / 2, 0, 0]}
          color="#ffffff"
        />
        <Lightformer
          form="ring"
          intensity={1.8}
          position={[-5, 2, -2]}
          scale={4}
          color={t.rimLightColor}
        />
        <Lightformer
          form="rect"
          intensity={1.5}
          position={[5, 3, 1]}
          scale={[3, 8, 1]}
          rotation={[0, -Math.PI / 2, 0]}
          color="#e8f7ff"
        />
      </Environment>

      {/* Reflective 3D Podium(s) */}
      <group rotation-y={frame * 0.0022}>
        {t.multiTierPodium ? (
          <>
            <mesh receiveShadow castShadow position={[0, -1.0, 0]}>
              <cylinderGeometry args={[1.45, 1.55, 0.7, 96]} />
              <meshStandardMaterial
                color={t.podiumColor}
                metalness={0.62}
                roughness={0.18}
              />
            </mesh>
            <mesh receiveShadow castShadow position={[-1.95, -1.25, -0.4]}>
              <cylinderGeometry args={[1.15, 1.25, 0.5, 96]} />
              <meshStandardMaterial
                color={t.podiumColor}
                metalness={0.58}
                roughness={0.2}
              />
            </mesh>
            <mesh receiveShadow castShadow position={[1.95, -1.18, -0.35]}>
              <cylinderGeometry args={[1.15, 1.25, 0.58, 96]} />
              <meshStandardMaterial
                color={t.podiumColor}
                metalness={0.58}
                roughness={0.2}
              />
            </mesh>
          </>
        ) : (
          <mesh receiveShadow castShadow position={[0, -1.05, 0]}>
            <cylinderGeometry args={[2.5, 2.6, 0.52, 128]} />
            <meshStandardMaterial
              color={t.podiumColor}
              metalness={0.65}
              roughness={0.18}
            />
          </mesh>
        )}
      </group>

      <Bubbles color={t.bubbleColor} />

      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, -1.35, 0]}
        receiveShadow
      >
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial
          color={t.floorColor}
          roughness={0.2}
          metalness={0.35}
        />
      </mesh>

      <EffectComposer>
        <Bloom
          luminanceThreshold={0.82}
          mipmapBlur
          intensity={0.42}
        />
        <Vignette eskil={false} offset={0.22} darkness={0.45} />
      </EffectComposer>
    </ThreeCanvas>
  );
};
