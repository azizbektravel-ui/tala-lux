import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';

interface WaterRippleProps {
  startFrame?: number;
  ringCount?: number;
  tint?: string;
}

export const WaterRipple: React.FC<WaterRippleProps> = ({
  startFrame = 0,
  ringCount = 5,
  tint = '#b5ecff',
}) => {
  const frame = useCurrentFrame();

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        overflow: 'hidden',
        pointerEvents: 'none',
      }}
    >
      {Array.from({length: ringCount}, (_, i) => {
        const t = frame - startFrame - i * 9;
        if (t < 0) return null;

        const scale = interpolate(t, [0, 110], [0.08, 4.2], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });

        const opacity = interpolate(t, [0, 16, 110], [0, 0.65, 0], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });

        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: '50%',
              top: '56%',
              width: 420,
              height: 175,
              borderRadius: '50%',
              border: `3px solid ${tint}`,
              opacity,
              boxShadow: `0 0 22px ${tint}88, inset 0 0 12px ${tint}55`,
              transform: `translate(-50%, -50%) scale(${scale})`,
            }}
          />
        );
      })}
    </div>
  );
};
