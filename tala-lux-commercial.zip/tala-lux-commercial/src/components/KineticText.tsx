import React from 'react';
import {
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from 'remotion';
import {MANROPE_FONT} from '../utils/fonts';
import {convertUzbek} from '../utils/uzbek';

interface KineticTextProps {
  text: string;
  applyUzbekTransform?: boolean;
  fontSize?: number;
  delay?: number;
  color?: string;
}

export const KineticText: React.FC<KineticTextProps> = ({
  text,
  applyUzbekTransform = true,
  fontSize = 68,
  delay = 8,
  color = '#ffffff',
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const displayText = applyUzbekTransform ? convertUzbek(text) : text;
  const words = displayText.split(' ');

  const tracking = interpolate(frame - delay, [0, 40], [0.12, 0.03], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        flexWrap: 'wrap',
        columnGap: 18,
        rowGap: 10,
        maxWidth: 900,
        padding: '0 40px',
        textAlign: 'center',
        fontFamily: `${MANROPE_FONT}, sans-serif`,
        fontSize,
        fontWeight: 800,
        color,
        lineHeight: 1.08,
        letterSpacing: `${tracking}em`,
        textShadow: '0 10px 30px rgba(0, 8, 22, 0.55)',
      }}
    >
      {words.map((word, i) => {
        const localFrame = frame - delay - i * 5;

        const progress = spring({
          frame: Math.max(0, localFrame),
          fps,
          config: {
            damping: 18,
            stiffness: 120,
          },
        });

        const opacity = interpolate(localFrame, [0, 12], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });

        const scale = interpolate(progress, [0, 1], [0.92, 1]);

        return (
          <span
            key={`${word}-${i}`}
            style={{
              overflow: 'hidden',
              display: 'inline-block',
              paddingBottom: 6,
            }}
          >
            <span
              style={{
                display: 'inline-block',
                opacity,
                transform: `translateY(${84 * (1 - progress)}px) scale(${scale})`,
                filter: `blur(${9 * (1 - opacity)}px)`,
              }}
            >
              {word}
            </span>
          </span>
        );
      })}
    </div>
  );
};
