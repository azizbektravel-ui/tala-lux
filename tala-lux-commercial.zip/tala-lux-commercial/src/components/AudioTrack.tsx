import React from 'react';
import {Audio, Sequence, staticFile, interpolate} from 'remotion';

/**
 * Enable audio tracks once voice-01..06.mp3, music.mp3, and SFX WAV files
 * are placed in public/audio/. Music automatically ducks during narration windows.
 */
interface AudioTrackProps {
  enableAudio?: boolean;
}

const VOICE_WINDOWS: Array<[number, number]> = [
  [18, 200],
  [258, 495],
  [558, 795],
  [858, 1095],
  [1158, 1395],
  [1460, 1755],
];

const getMusicVolume = (frame: number): number => {
  const isNarrating = VOICE_WINDOWS.some(
    ([start, end]) => frame >= start && frame <= end
  );
  const base = isNarrating ? 0.22 : 0.48;
  const fadeOut = interpolate(frame, [1710, 1800], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return base * fadeOut;
};

export const AudioTrack: React.FC<AudioTrackProps> = ({enableAudio = false}) => {
  if (!enableAudio) {
    return null;
  }

  return (
    <>
      <Audio src={staticFile('audio/music.mp3')} volume={getMusicVolume} />

      <Sequence from={18} durationInFrames={210}>
        <Audio src={staticFile('audio/voice-01.mp3')} volume={1} />
      </Sequence>
      <Sequence from={258} durationInFrames={250}>
        <Audio src={staticFile('audio/voice-02.mp3')} volume={1} />
      </Sequence>
      <Sequence from={558} durationInFrames={250}>
        <Audio src={staticFile('audio/voice-03.mp3')} volume={1} />
      </Sequence>
      <Sequence from={858} durationInFrames={250}>
        <Audio src={staticFile('audio/voice-04.mp3')} volume={1} />
      </Sequence>
      <Sequence from={1158} durationInFrames={250}>
        <Audio src={staticFile('audio/voice-05.mp3')} volume={1} />
      </Sequence>
      <Sequence from={1460} durationInFrames={320}>
        <Audio src={staticFile('audio/voice-06.mp3')} volume={1} />
      </Sequence>

      {/* Beat-aligned SFX */}
      <Sequence from={105} durationInFrames={90}>
        <Audio src={staticFile('audio/splash.wav')} volume={0.75} />
      </Sequence>
      <Sequence from={232} durationInFrames={45}>
        <Audio src={staticFile('audio/whoosh.wav')} volume={0.6} />
      </Sequence>
      <Sequence from={532} durationInFrames={45}>
        <Audio src={staticFile('audio/whoosh.wav')} volume={0.6} />
      </Sequence>
      <Sequence from={832} durationInFrames={45}>
        <Audio src={staticFile('audio/whoosh.wav')} volume={0.6} />
      </Sequence>
      <Sequence from={1132} durationInFrames={45}>
        <Audio src={staticFile('audio/whoosh.wav')} volume={0.6} />
      </Sequence>
      <Sequence from={1440} durationInFrames={90}>
        <Audio src={staticFile('audio/impact.wav')} volume={0.8} />
      </Sequence>
    </>
  );
};
