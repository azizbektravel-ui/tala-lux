import React, {useMemo} from 'react';
import {useCurrentFrame, random} from 'remotion';

interface BubblesProps {
  count?: number;
  color?: string;
  opacity?: number;
}

export const Bubbles: React.FC<BubblesProps> = ({
  count = 90,
  color = '#b9efff',
  opacity = 0.28,
}) => {
  const frame = useCurrentFrame();

  const items = useMemo(
    () =>
      Array.from({length: count}, (_, i) => ({
        x: random(`bubble-x-${i}`) * 8 - 4,
        y0: random(`bubble-y-${i}`) * 10,
        z: random(`bubble-z-${i}`) * 6 - 3,
        speed: 0.015 + random(`bubble-s-${i}`) * 0.032,
        radius: 0.025 + random(`bubble-r-${i}`) * 0.14,
        phase: random(`bubble-p-${i}`) * Math.PI * 2,
      })),
    [count]
  );

  return (
    <group>
      {items.map((b, i) => {
        const y = ((b.y0 + frame * b.speed) % 10) - 5;
        const x = b.x + Math.sin(frame * 0.022 + b.phase) * 0.16;

        return (
          <mesh key={i} position={[x, y, b.z]}>
            <sphereGeometry args={[b.radius, 24, 24]} />
            <meshPhysicalMaterial
              color={color}
              transparent
              opacity={opacity}
              roughness={0.04}
              metalness={0.08}
              clearcoat={1}
              clearcoatRoughness={0.04}
              reflectivity={0.95}
              depthWrite={false}
            />
          </mesh>
        );
      })}
    </group>
  );
};
