import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Studio} from '../components/Studio';
import {FloatingProduct} from '../components/FloatingProduct';
import {KineticText} from '../components/KineticText';

/**
 * SCENE 04 — 00:14–00:19 (Frames 840–1139)
 * Stain remover / oxygen cleaner with illustrative oxygen bubbles.
 */
export const StainRemover: React.FC = () => {
  return (
    <AbsoluteFill>
      <Studio
        durationInFrames={300}
        theme={{
          bgColor: '#112545',
          floorColor: '#1a3866',
          podiumColor: '#e4eefc',
          rimLightColor: '#7aaeff',
          bubbleColor: '#e3f2ff',
          cameraDollyZ: [9.2, 8.0],
        }}
      />

      <AbsoluteFill
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          paddingTop: 110,
        }}
      >
        <FloatingProduct
          image="products/stain-remover.png"
          width={620}
          rimGlowColor="rgba(130, 185, 255, 0.42)"
        />
      </AbsoluteFill>

      <AbsoluteFill
        style={{
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingTop: 260,
        }}
      >
        <KineticText text="DOG'LARGA QARSHI YECHIM" delay={16} fontSize={68} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
