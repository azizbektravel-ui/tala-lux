import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Studio} from '../components/Studio';
import {FloatingProduct} from '../components/FloatingProduct';
import {KineticText} from '../components/KineticText';

/**
 * SCENE 02 — 00:04–00:09 (Frames 240–539)
 * Dishwashing gel hero shot in a fresh emerald/citrus studio environment.
 */
export const Dishwash: React.FC = () => {
  return (
    <AbsoluteFill>
      <Studio
        durationInFrames={300}
        theme={{
          bgColor: '#0a2e22',
          floorColor: '#124634',
          podiumColor: '#dff5e1',
          rimLightColor: '#8df06e',
          bubbleColor: '#d9ffbf',
          cameraDollyZ: [9.2, 8.1],
        }}
      />

      <AbsoluteFill
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          paddingTop: 110,
        }}
      >
        <FloatingProduct
          image="products/dishwash.png"
          width={640}
          rimGlowColor="rgba(162, 245, 118, 0.38)"
        />
      </AbsoluteFill>

      <AbsoluteFill
        style={{
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingTop: 260,
        }}
      >
        <KineticText text="YORQIN TOZALIK" delay={16} fontSize={74} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
