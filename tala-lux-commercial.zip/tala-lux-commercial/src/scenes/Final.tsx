import React from 'react';
import {
  AbsoluteFill,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from 'remotion';
import {Studio} from '../components/Studio';
import {FloatingProduct} from '../components/FloatingProduct';
import {KineticText} from '../components/KineticText';
import {MANROPE_FONT} from '../utils/fonts';

/**
 * SCENE 06 — 00:24–00:30 (Frames 1440–1799, 360 frames = 6s)
 * Final product lineup on multi-tier 3D podium + TALA LUX logo & slogan held >= 2 seconds.
 */
export const Final: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const logoSpring = spring({
    frame: Math.max(0, frame - 80),
    fps,
    config: {damping: 18, stiffness: 110},
  });

  const urlOpacity = interpolate(frame, [130, 165], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill>
      <Studio
        durationInFrames={360}
        theme={{
          bgColor: '#081d33',
          floorColor: '#103152',
          podiumColor: '#dfeeff',
          rimLightColor: '#63ccff',
          bubbleColor: '#c9f2ff',
          multiTierPodium: true,
          cameraDollyZ: [9.8, 8.3],
        }}
      />

      {/* Beat-sequenced product lineup */}
      <AbsoluteFill
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 12,
          paddingTop: 180,
        }}
      >
        <div style={{transform: 'translateY(36px)'}}>
          <FloatingProduct
            image="products/glass-cleaner.png"
            width={235}
            delay={12}
            floatAmplitude={8}
            showContactShadow={false}
          />
        </div>
        <div style={{transform: 'translateY(-16px)'}}>
          <FloatingProduct
            image="products/dishwash.png"
            width={265}
            delay={26}
            floatAmplitude={10}
            showContactShadow={false}
          />
        </div>
        <div style={{transform: 'translateY(10px)'}}>
          <FloatingProduct
            image="products/laundry.png"
            width={260}
            delay={40}
            floatAmplitude={9}
            showContactShadow={false}
          />
        </div>
        <div style={{transform: 'translateY(42px)'}}>
          <FloatingProduct
            image="products/stain-remover.png"
            width={230}
            delay={54}
            floatAmplitude={8}
            showContactShadow={false}
          />
        </div>
      </AbsoluteFill>

      {/* Authentic TALA LUX Logo + Slogan (readable for >3 seconds) */}
      <AbsoluteFill
        style={{
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingTop: 220,
          gap: 24,
        }}
      >
        <Img
          src={staticFile('logo.png')}
          style={{
            width: 440,
            objectFit: 'contain',
            opacity: logoSpring,
            transform: `scale(${interpolate(logoSpring, [0, 1], [0.85, 1])})`,
            filter: 'drop-shadow(0 18px 30px rgba(0, 8, 22, 0.55))',
          }}
        />

        <KineticText
          text="SIFAT NARXDAN ANCHA YUQORI"
          delay={105}
          fontSize={56}
        />

        <div
          style={{
            marginTop: 8,
            fontFamily: `${MANROPE_FONT}, sans-serif`,
            fontSize: 38,
            fontWeight: 700,
            letterSpacing: '0.14em',
            color: '#9ee7ff',
            opacity: urlOpacity,
          }}
        >
          talalux.uz
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
