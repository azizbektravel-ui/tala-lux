import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Studio} from '../components/Studio';
import {FloatingProduct} from '../components/FloatingProduct';
import {KineticText} from '../components/KineticText';

/**
 * SCENE 03 — 00:09–00:14 (Frames 540–839)
 * Laundry detergent hero shot in a crisp alpine blue-and-white studio environment.
 */
export const Laundry: React.FC = () => {
  return (
    <AbsoluteFill>
      <Studio
        durationInFrames={300}
        theme={{
          bgColor: '#0f2b4c',
          floorColor: '#1a426e',
          podiumColor: '#eef6ff',
          rimLightColor: '#7fd4ff',
          bubbleColor: '#d8f3ff',
          cameraDollyZ: [9.3, 8.2],
        }}
      />

      <AbsoluteFill
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          paddingTop: 110,
        }}
      >
        <FloatingProduct
          image="products/laundry.png"
          width={640}
          rimGlowColor="rgba(140, 220, 255, 0.42)"
        />
      </AbsoluteFill>

      <AbsoluteFill
        style={{
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingTop: 260,
        }}
      >
        <KineticText text="YANGILIK NAFASI" delay={16} fontSize={74} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
