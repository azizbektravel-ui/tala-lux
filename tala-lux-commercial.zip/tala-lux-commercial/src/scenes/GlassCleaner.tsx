import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Studio} from '../components/Studio';
import {FloatingProduct} from '../components/FloatingProduct';
import {KineticText} from '../components/KineticText';

/**
 * SCENE 05 — 00:19–00:24 (Frames 1140–1439)
 * Glass cleaner reveal through a transparent glass sheen with subtle sparkle.
 */
export const GlassCleaner: React.FC = () => {
  const frame = useCurrentFrame();

  const glassRevealX = interpolate(frame, [0, 75], [0, 1180], {
    extrapolateRight: 'clamp',
  });
  const glassOpacity = interpolate(frame, [40, 85], [0.42, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill>
      <Studio
        durationInFrames={300}
        theme={{
          bgColor: '#0b2c40',
          floorColor: '#14445e',
          podiumColor: '#e1f4fc',
          rimLightColor: '#6be5ff',
          bubbleColor: '#ccf7ff',
          cameraDollyZ: [9.4, 8.1],
        }}
      />

      <AbsoluteFill
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          paddingTop: 110,
        }}
      >
        <FloatingProduct
          image="products/glass-cleaner.png"
          width={620}
          rimGlowColor="rgba(115, 234, 255, 0.45)"
        />
      </AbsoluteFill>

      {/* Transparent glass wipe shimmer */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'linear-gradient(115deg, rgba(255,255,255,0) 20%, rgba(210,248,255,0.55) 50%, rgba(255,255,255,0) 80%)',
          transform: `translateX(${glassRevealX - 300}px)`,
          opacity: glassOpacity,
          pointerEvents: 'none',
        }}
      />

      <AbsoluteFill
        style={{
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingTop: 260,
        }}
      >
        <KineticText text="MUSAFFO TOZALIK" delay={18} fontSize={74} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
