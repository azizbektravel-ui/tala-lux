import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Studio} from '../components/Studio';
import {WaterRipple} from '../components/WaterRipple';
import {KineticText} from '../components/KineticText';

/**
 * SCENE 01 — 00:00–00:04 (Frames 0–239)
 * Single transparent water droplet falls into a reflective deep-blue studio surface.
 */
export const Intro: React.FC = () => {
  const frame = useCurrentFrame();

  const dropY = interpolate(frame, [10, 108], [-120, 1060], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const dropOpacity = interpolate(frame, [10, 22, 105, 112], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill>
      <Studio
        durationInFrames={240}
        theme={{
          bgColor: '#071b30',
          floorColor: '#0c2c4a',
          podiumColor: '#a8d5f7',
          rimLightColor: '#4cc9ff',
          bubbleColor: '#b9efff',
          cameraDollyZ: [9.8, 8.4],
        }}
      />

      {/* Macro falling water droplet */}
      <div
        style={{
          position: 'absolute',
          left: '50%',
          top: dropY,
          width: 46,
          height: 68,
          marginLeft: -23,
          borderRadius: '50% 50% 50% 50% / 62% 62% 38% 38%',
          background:
            'radial-gradient(circle at 35% 32%, #ffffff 0%, #9ee7ff 38%, #1e88d6 85%)',
          boxShadow: '0 0 36px rgba(105, 218, 255, 0.7)',
          opacity: dropOpacity,
        }}
      />

      <WaterRipple startFrame={105} ringCount={5} tint="#b5ecff" />

      {/* Vertical safe-zone headline */}
      <AbsoluteFill
        style={{
          justifyContent: 'flex-start',
          alignItems: 'center',
          paddingTop: 290,
        }}
      >
        <KineticText text="TOZALIK BIR TOMCHIDAN BOSHLANADI" delay={24} fontSize={66} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
