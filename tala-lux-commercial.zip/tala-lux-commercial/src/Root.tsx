import React from 'react';
import {Composition} from 'remotion';
import {Commercial} from './Commercial';

export const Root: React.FC = () => {
  return (
    <Composition
      id="TalaLux"
      component={Commercial}
      durationInFrames={1800}
      fps={60}
      width={1080}
      height={1920}
    />
  );
};
