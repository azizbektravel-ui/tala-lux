import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {Intro} from './scenes/Intro';
import {Dishwash} from './scenes/Dishwash';
import {Laundry} from './scenes/Laundry';
import {StainRemover} from './scenes/StainRemover';
import {GlassCleaner} from './scenes/GlassCleaner';
import {Final} from './scenes/Final';
import {AudioTrack} from './components/AudioTrack';

/**
 * Master 30-second (1800 frames @ 60fps, 1080x1920) TALA LUX — CLEAN WORLD Commercial.
 * Set enableAudio={true} once voice-01..06.mp3, music.mp3, and SFX WAV files are added to public/audio/.
 */
export const Commercial: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#061827'}}>
      <Sequence from={0} durationInFrames={240}>
        <Intro />
      </Sequence>

      <Sequence from={240} durationInFrames={300}>
        <Dishwash />
      </Sequence>

      <Sequence from={540} durationInFrames={300}>
        <Laundry />
      </Sequence>

      <Sequence from={840} durationInFrames={300}>
        <StainRemover />
      </Sequence>

      <Sequence from={1140} durationInFrames={300}>
        <GlassCleaner />
      </Sequence>

      <Sequence from={1440} durationInFrames={360}>
        <Final />
      </Sequence>

      <AudioTrack enableAudio={false} />
    </AbsoluteFill>
  );
};
