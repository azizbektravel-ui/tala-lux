import {loadFont} from '@remotion/google-fonts/Manrope';

export const {fontFamily: MANROPE_FONT} = loadFont('normal', {
  weights: ['600', '700', '800'],
  subsets: ['latin', 'latin-ext'],
});
