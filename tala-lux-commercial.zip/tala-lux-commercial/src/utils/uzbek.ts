/**
 * Converts standard Uzbek Latin orthography to the stylized on-screen display alphabet.
 * Apply ONLY to intended on-screen Uzbek copy — never to URLs, filenames, or "TALA LUX".
 */
export const convertUzbek = (text: string): string =>
  text
    .replace(/O['‘’ʻʼ]/g, 'Ö')
    .replace(/G['‘’ʻʼ]/g, 'Ğ')
    .replace(/o['‘’ʻʼ]/g, 'ö')
    .replace(/g['‘’ʻʼ]/g, 'ğ')
    .replace(/SH/g, 'Ş')
    .replace(/Sh/g, 'Ş')
    .replace(/sh/g, 'ş')
    .replace(/CH/g, 'Ç')
    .replace(/Ch/g, 'Ç')
    .replace(/ch/g, 'ç');
